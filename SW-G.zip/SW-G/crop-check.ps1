# crop-check.ps1 — 对图片生成结果做 aspect 校验 + 按需中心裁切（本地操作）
param(
  [Parameter(Mandatory = $true)][string]$OutputDir,
  [Parameter(Mandatory = $true)][string]$Aspect
)
Add-Type -AssemblyName System.Drawing
$target = switch ($Aspect.ToLowerInvariant()) {
  '16:9' { 16.0 / 9.0 }
  '4:3'  { 4.0 / 3.0 }
  '3:4'  { 3.0 / 4.0 }
  '1:1'  { 1.0 }
  '3:2'  { 3.0 / 2.0 }
  default { 0 }
}
if ($target -le 0) { throw "未知比例: $Aspect" }
Get-ChildItem -Path $OutputDir -Filter "*.png" | ForEach-Object {
  $img = [System.Drawing.Bitmap]::FromFile($_.FullName)
  try {
    $w = $img.Width; $h = $img.Height
    $ratio = $w / $h
    $ok = [math]::Abs($ratio - $target) -lt 0.04
    if ($ok) { Write-Output "  OK  $($_.Name) ${w}x${h} (ratio $([math]::Round($ratio,3)))" }
    else {
      # 中心裁切
      $nw = $w; $nh = [int]($w / $target)
      if ($nh -gt $h) { $nh = $h; $nw = [int]($h * $target) }
      $x = [int](($w - $nw) / 2); $y = [int](($h - $nh) / 2)
      $tmp = Join-Path $_.DirectoryName ("__crop_{0}.png" -f ([guid]::NewGuid().ToString('N').Substring(0,8)))
      $crop = New-Object System.Drawing.Bitmap($nw, $nh)
      $g = [System.Drawing.Graphics]::FromImage($crop)
      $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
      $g.DrawImage($img, (New-Object System.Drawing.Rectangle(0,0,$nw,$nh)), (New-Object System.Drawing.Rectangle($x,$y,$nw,$nh)), [System.Drawing.GraphicsUnit]::Pixel)
      $crop.Save($tmp, [System.Drawing.Imaging.ImageFormat]::Png)
      $g.Dispose(); $crop.Dispose()
      Remove-Item $_.FullName -Force
      Move-Item $tmp $_.FullName
      Write-Output "  CROP $($_.Name) ${w}x${h} -> ${nw}x${nh} (ratio $([math]::Round($ratio,3)) -> $([math]::Round($target,3)))"
    }
  } finally { $img.Dispose() }
}
