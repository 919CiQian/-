// 顺序执行多平台图片生成：同一时刻只跑一个平台，避免网关限流
import { execFileSync } from "node:child_process";

const jobsList = [
  ["D:/GEOAgent/runs/SW-G/今日头条素材/图片/jobs-toutiao.json"],
  ["D:/GEOAgent/runs/SW-G/百家号素材/图片/jobs-baijiahao.json"],
  ["D:/GEOAgent/runs/SW-G/小红书素材/图片/jobs-rednote.json"],
  ["D:/GEOAgent/runs/SW-G/微博素材/图片/jobs-weibo.json"],
  ["D:/GEOAgent/runs/SW-G/知乎素材/图片/jobs-zhihu.json"],
];

const gen = "D:/GEOAgent/runs/SW-G/抖音图文素材/图片/geo-image-generator-node.mjs";
const results = [];
for (const [jobsPath] of jobsList) {
  console.log(`\n===== ${jobsPath} =====`);
  try {
    execFileSync(process.execPath, [gen, jobsPath], { stdio: "inherit" });
    results.push({ jobsPath, ok: true });
  } catch (e) {
    // 单平台某张失败不算整体崩溃；node 已写 summary
    results.push({ jobsPath, ok: false, code: e.status ?? e.message });
  }
}
console.log("\n===== 汇总 =====");
for (const r of results) console.log(`${r.ok ? "OK  " : "FAIL"} ${r.jobsPath} ${r.code ?? ""}`);
