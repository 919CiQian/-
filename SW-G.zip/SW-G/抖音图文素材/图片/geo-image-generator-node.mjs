// geo-image-generator-node.mjs — geo-image-generation 技能的 node 等价执行器
// 契约与 generate_images.ps1 一致：逐张 n=1、aspect 校验、重试、写 summary.json。
// 网络用 node fetch（沙箱内 PowerShell 出网被拦但 node 可用）；裁切校验在生成后由外部步骤做。
import { readFileSync, writeFileSync, mkdirSync, existsSync, unlinkSync } from "node:fs";
import path from "node:path";

const args = process.argv.slice(2);
const jobsPath = args[0];
const key = readFileSync("D:/GEOAgent/.dsh/geo-image-key.txt", "utf8").trim();
const cfg = JSON.parse(readFileSync(jobsPath, "utf8"));
const endpoint = cfg.endpoint || "https://sub2api.vx123.xin/v1/images/generations";
const MODEL = "gpt-image-2"; // 技能固定模型
const timeoutSec = cfg.timeout_sec || 200;
const maxRetries = cfg.max_retries || 3;
const outDir = cfg.output_dir;
mkdirSync(outDir, { recursive: true });

const aspectRatio = { "16:9": 16/9, "4:3": 4/3, "3:4": 3/4, "1:1": 1 };
const FALLBACKS = ["1024x768", "1024x1536", "1024x1024", "1536x1024"];

function pngSize(buf) {
  // PNG 头部：8 字节签名 + IHDR 长度(4) + "IHDR"(4) + width(4 BE) + height(4 BE)
  if (buf.length < 24 || buf.toString("ascii", 1, 4) !== "PNG") return null;
  if (buf.toString("ascii", 12, 16) !== "IHDR") return null;
  return { w: buf.readUInt32BE(16), h: buf.readUInt32BE(20) };
}

async function genOne(prompt, size, attemptLabels) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutSec * 1000);
  try {
    const resp = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
      body: JSON.stringify({ model: MODEL, prompt, n: 1, size, response_format: "b64_json" }),
      signal: ctrl.signal,
    });
    const text = await resp.text();
    if (!resp.ok) {
      let msg = text.slice(0, 200);
      try { const j = JSON.parse(text); msg = j?.error?.message || msg; } catch {}
      throw new Error(`HTTP ${resp.status}: ${msg}`);
    }
    const j = JSON.parse(text);
    const b64 = j?.data?.[0]?.b64_json;
    if (!b64) throw new Error("empty b64_json in response");
    return Buffer.from(b64, "base64");
  } finally {
    clearTimeout(t);
  }
}

const summary = {
  endpoint, model: MODEL, output_dir: outDir,
  generated_at: new Date().toISOString(),
  images: [], logs: [],
};
let allOk = true;

for (const item of cfg.images) {
  const entry = { file: item.file, prompt: item.prompt, status: "pending", attempts: 0, dims: "", logs: [] };
  try {
    const pathFull = path.join(outDir, item.file);
    const target = item.aspect && aspectRatio[item.aspect] ? aspectRatio[item.aspect] : 0;
    const sizes = [];
    if (item.size) sizes.push(String(item.size));
    for (const fb of FALLBACKS) if (!sizes.includes(fb)) sizes.push(fb);

    let saved = false;
    for (let attempt = 1; attempt <= maxRetries && !saved; attempt++) {
      entry.attempts = attempt;
      const sz = sizes[Math.min(attempt - 1, sizes.length - 1)];
      try {
        const buf = await genOne(item.prompt, sz, entry.logs);
        if (existsSync(pathFull)) unlinkSync(pathFull);
        writeFileSync(pathFull, buf);
        const dims = pngSize(buf);
        entry.dims = dims ? `${dims.w}x${dims.h}` : "unknown";
        if (dims) {
          const ratio = dims.w / dims.h;
          const okRatio = target <= 0 || Math.abs(ratio - target) < 0.04;
          if (okRatio) { saved = true; }
          else { entry.logs.push(`attempt ${attempt}: size ${sz} returned ${dims.w}x${dims.h} (aspect mismatch) → retry`); }
        } else {
          // 无 PNG 头则按成功落盘但标记尺寸未知
          entry.logs.push(`attempt ${attempt}: saved but PNG header not readable`);
          saved = true;
        }
      } catch (e) {
        entry.logs.push(`attempt ${attempt}: ${e.message}`);
      }
    }
    entry.status = saved ? (entry.logs.some(l => l.includes("mismatch")) ? "needs-crop-check" : "ok") : "failed";
    if (entry.status === "failed") allOk = false;
  } catch (e) {
    entry.status = "failed";
    entry.logs.push(e.message);
    allOk = false;
  }
  summary.images.push(entry);
  console.log(`[${entry.status}] ${entry.file} dims=${entry.dims} attempts=${entry.attempts} ${entry.logs.join(" | ")}`);
}

writeFileSync(path.join(outDir, "summary.json"), JSON.stringify(summary, null, 2), "utf8");
console.log(`\nDONE allOk=${allOk} → ${path.join(outDir, "summary.json")}`);
process.exit(allOk ? 0 : 1);
